﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PresentsData;
using PresentsData.Entities;

namespace PresentsWebApp.Controllers
{
    public class CategorieController : Controller
    {
        private readonly GiftContext context;

        public CategorieController(GiftContext _context)
        {
            context = _context;
        }
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Categorie categorie)
        {
            context.Categories.Add(categorie);
            await context.SaveChangesAsync();
            return RedirectToAction("Create");
        }
    }
}
