﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PresentsData;
using PresentsData.Entities;

namespace PresentsWebApp.Controllers
{
    public class GiftsController : Controller
    {
        private readonly GiftContext context;

        public GiftsController(GiftContext _context)
        {
            context = _context;
        }

        public async Task<IActionResult> Index()
        {
            var gifts = await context.Gifts.Include(c => c.categorie).ToListAsync();
            return View(gifts);
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {

            var categorie = await context.Categories.ToListAsync();
            ViewBag.Categories = new SelectList(categorie, "Id", "Name");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Gift gift)
        {
            context.Gifts.Add(gift);
            await context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

       

        [HttpPost]
        public async Task<IActionResult> Down()
        {
            
            int total = context.Gifts.Where(g=>g.IsTakeb == false).Count();
            Random r = new Random();
            int offset = r.Next(0, total);

            var gift = context.Gifts.Skip(offset).FirstOrDefault();
  
            gift.IsTakeb = true;
            await context.SaveChangesAsync();
            return View(gift);
        }
    }
}
