﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentsData.Entities
{
    public class Gift
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public Categorie categorie { get; set; }

        [ForeignKey("Categorie")]
        public Guid CategorieId { get; set; }

        public bool IsTakeb {  get; set; }  = false;
    }
}
